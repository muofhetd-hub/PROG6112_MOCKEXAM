package question2;

import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;

// Q2.1 - Q2.6 GUI Application
public class MovieTicketGUI extends JFrame {
    private JComboBox<String> cmbMovie;
    private JTextField txtNumTickets;
    private JTextField txtTicketPrice;
    private JTextArea txtReport;
    private MovieTickets movieTickets = new MovieTickets();

    public MovieTicketGUI() {
        setTitle("Movie Ticket Sales - ST10538032");
        setSize(500, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Top panel - inputs
        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        inputPanel.add(new JLabel("Movie:"));
        cmbMovie = new JComboBox<>(new String[]{"Napoleon", "Oppenheimer", "Damsel"});
        inputPanel.add(cmbMovie);
        inputPanel.add(new JLabel("Number of Movie Tickets:"));
        txtNumTickets = new JTextField();
        inputPanel.add(txtNumTickets);
        inputPanel.add(new JLabel("Movie Ticket Price:"));
        txtTicketPrice = new JTextField();
        inputPanel.add(txtTicketPrice);
        add(inputPanel, BorderLayout.NORTH);

        // Centre - report area read-only
        txtReport = new JTextArea();
        txtReport.setEditable(false);
        txtReport.setFont(new Font("Monospaced", Font.PLAIN, 12));
        add(new JScrollPane(txtReport), BorderLayout.CENTER);

        // Menu system Q2.2
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0)); // Q2.3
        fileMenu.add(exitItem);

        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processItem = new JMenuItem("Process");
        processItem.addActionListener(e -> processTicket());
        JMenuItem clearItem = new JMenuItem("Clear");
        clearItem.addActionListener(e -> clearForm()); // Q2.6
        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);
    }

    // Q2.4 Process
    private void processTicket() {
        try {
            String movie = (String) cmbMovie.getSelectedItem();
            int numTickets = Integer.parseInt(txtNumTickets.getText().trim());
            double price = Double.parseDouble(txtTicketPrice.getText().trim());

            MovieTicketData data = new MovieTicketData(movie, numTickets, price);

            if (!movieTickets.ValidateData(data)) {
                JOptionPane.showMessageDialog(this, "Invalid data! Check: Movie name not empty, Price > 0, Tickets > 0",
                        "Validation Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            double total = movieTickets.CalculateTotalTicketPrice(numTickets, price);
            double subTotal = numTickets * price;
            double vat = subTotal * 0.14;

            String report = "MOVIE TICKET SALES REPORT\n"
                    + "-------------------------\n"
                    + "Movie: " + movie + "\n"
                    + "Number of Tickets: " + numTickets + "\n"
                    + "Ticket Price: R " + String.format("%.2f", price) + "\n"
                    + "VAT (14%): R " + String.format("%.2f", vat) + "\n"
                    + "Total Ticket Price (incl VAT): R " + String.format("%.2f", total) + "\n";

            txtReport.setText(report);
            saveReport(report); // Q2.5
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for tickets and price.",
                    "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Q2.5 Save to report.txt
    private void saveReport(String report) {
        try (FileWriter writer = new FileWriter("report.txt")) {
            writer.write(report);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving report.txt: " + ex.getMessage());
        }
    }

    private void clearForm() {
        cmbMovie.setSelectedIndex(0);
        txtNumTickets.setText("");
        txtTicketPrice.setText("");
        txtReport.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MovieTicketGUI().setVisible(true));
    }
}
