package question2.test;
import org.junit.Test;
import static org.junit.Assert.*;
import question2.MovieTickets;
import question2.MovieTicketData;

// Q2.9 Unit Tests
public class MovieTicketsTest {

    @Test
    public void CalculateTotalTicketPrice_CalculatedSuccessfully() {
        MovieTickets mt = new MovieTickets();
        // 2 tickets x R100 = R200 + 14% VAT (R28) = R228
        double expected = 228.0;
        double actual = mt.CalculateTotalTicketPrice(2, 100.0);
        assertEquals(expected, actual, 0.01);
    }

    @Test
    public void Validation_InvalidTicketPrice_ReturnsFalse() {
        MovieTickets mt = new MovieTickets();
        MovieTicketData invalid = new MovieTicketData("Napoleon", 2, 0); // price <= 0 invalid
        assertFalse(mt.ValidateData(invalid));
    }

    @Test
    public void Validation_ValidData_ReturnsTrue() {
        MovieTickets mt = new MovieTickets();
        MovieTicketData valid = new MovieTicketData("Oppenheimer", 3, 120.0);
        assertTrue(mt.ValidateData(valid));
    }
}
