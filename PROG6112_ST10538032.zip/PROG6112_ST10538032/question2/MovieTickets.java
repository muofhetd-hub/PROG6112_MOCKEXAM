package question2;

// Q2.7 Implements IMovieTickets - VAT 14%
public class MovieTickets implements IMovieTickets {
    private static final double VAT = 0.14;

    @Override
    public double CalculateTotalTicketPrice(int numberOfTickets, double ticketPrice) {
        double subTotal = numberOfTickets * ticketPrice;
        double vatAmount = subTotal * VAT;
        return subTotal + vatAmount;
    }

    @Override
    public boolean ValidateData(MovieTicketData data) {
        // Validation rules from Q2.7
        if (data.getMovieName() == null || data.getMovieName().trim().isEmpty()) {
            return false;
        }
        if (data.getTicketPrice() <= 0) {
            return false;
        }
        if (data.getNumberOfTickets() <= 0) {
            return false;
        }
        return true;
    }
}
