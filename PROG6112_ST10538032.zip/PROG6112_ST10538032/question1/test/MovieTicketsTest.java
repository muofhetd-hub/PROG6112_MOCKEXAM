package question1.test;
import org.junit.Test;
import static org.junit.Assert.*;
import question1.MovieTickets;

// Q1.3 Unit Tests
public class MovieTicketsTest {

    @Test
    public void CalculateTotalSales_ReturnsExpectedTotalSales() {
        MovieTickets mt = new MovieTickets();
        int[] napoleonSales = {3000, 1500, 1700};
        int expected = 6200;
        int actual = mt.TotalMovieSales(napoleonSales);
        assertEquals(expected, actual);
    }

    @Test
    public void TopMovieSales_ReturnsTopMovie() {
        MovieTickets mt = new MovieTickets();
        String[] movies = {"Napoleon", "Oppenheimer"};
        int[] totals = {6200, 6300};
        String expected = "Oppenheimer";
        String actual = mt.TopMovie(movies, totals);
        assertEquals(expected, actual);
    }
}
