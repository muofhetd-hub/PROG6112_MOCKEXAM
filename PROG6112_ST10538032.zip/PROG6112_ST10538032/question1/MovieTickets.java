package question1;

// Q1.2 - Implements IMovieTickets
public class MovieTickets implements IMovieTickets {

    // Sums all sales in the array e.g. Jan+Feb+Mar
    @Override
    public int TotalMovieSales(int[] movieTicketSales) {
        int total = 0;
        for (int sale : movieTicketSales) {
            total += sale;
        }
        return total;
    }

    // Returns movie with highest total sales
    @Override
    public String TopMovie(String[] movies, int[] totalSales) {
        int topIndex = 0;
        for (int i = 1; i < totalSales.length; i++) {
            if (totalSales[i] > totalSales[topIndex]) {
                topIndex = i;
            }
        }
        return movies[topIndex];
    }
}
