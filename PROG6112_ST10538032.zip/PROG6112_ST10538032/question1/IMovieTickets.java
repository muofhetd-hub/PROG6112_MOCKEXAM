package question1;

// Q1.2 - Interface for Question 1
// Student: Thendo David Muofhe - ST10538032
public interface IMovieTickets {
    int TotalMovieSales(int[] movieTicketSales);
    String TopMovie(String[] movies, int[] totalSales);
}
