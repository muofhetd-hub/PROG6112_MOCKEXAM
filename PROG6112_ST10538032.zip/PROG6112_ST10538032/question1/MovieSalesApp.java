package question1;

// Q1.1 - Main application using single + 2D arrays
public class MovieSalesApp {
    public static void main(String[] args) {
        // Single dimensional array - movie names
        String[] movies = {"Napoleon", "Oppenheimer"};

        // Single dimensional array - months
        String[] months = {"JAN", "FEB", "MAR"};

        // Two dimensional array - sales [movie][month]
        int[][] sales = {
            {3000, 1500, 1700}, // Napoleon
            {3500, 1200, 1600}  // Oppenheimer
        };

        MovieTickets tickets = new MovieTickets();
        int[] totalSales = new int[movies.length];

        // Calculate totals using MovieTickets class
        for (int i = 0; i < movies.length; i++) {
            totalSales[i] = tickets.TotalMovieSales(sales[i]);
        }

        // Print Report - as per sample screenshot
        System.out.println("MOVIE TICKET SALES REPORT");
        System.out.println("-------------------------");
        System.out.printf("%-15s", "MOVIE");
        for (String m : months) {
            System.out.printf("%-8s", m);
        }
        System.out.println("TOTAL");
        System.out.println("-------------------------");

        for (int i = 0; i < movies.length; i++) {
            System.out.printf("%-15s", movies[i]);
            for (int j = 0; j < months.length; j++) {
                System.out.printf("%-8d", sales[i][j]);
            }
            System.out.println(totalSales[i]);
        }
        System.out.println("-------------------------");
        System.out.println("TOP PERFORMING MOVIE: " + tickets.TopMovie(movies, totalSales));
    }
}
