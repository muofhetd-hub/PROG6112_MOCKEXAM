PROG6112 Exam - Thendo David Muofhe ST10538032
Q1: Run question1.MovieSalesApp - uses 1D + 2D arrays
Q2: Run question2.MovieTicketGUI - GUI with menu File>Exit, Tools>Process, Clear
Tests: Use JUnit 4 in NetBeans - right click test files > Run
